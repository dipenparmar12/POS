 <!-- BEGIN VENDOR JS-->
 <script src="../../../app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
 <!-- BEGIN VENDOR JS-->
 <!-- BEGIN PAGE VENDOR JS-->
 <!-- END PAGE VENDOR JS-->
 <!-- BEGIN MODERN JS-->
 <script src="../../../app-assets/js/core/app-menu.js" type="text/javascript"></script>
 <script src="../../../app-assets/js/core/app.js" type="text/javascript"></script>
 <script src="../../../app-assets/js/scripts/customizer.js" type="text/javascript"></script>
 <!-- END MODERN JS-->
 <!-- BEGIN PAGE LEVEL JS-->
 <script src="../../../app-assets/js/scripts/pages/email-application.js" type="text/javascript"></script>
 <!-- END PAGE LEVEL JS-->