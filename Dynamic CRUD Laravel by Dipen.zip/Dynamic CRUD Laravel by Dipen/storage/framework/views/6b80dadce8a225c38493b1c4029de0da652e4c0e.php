<?php $__env->startSection('content'); ?>

    <h3> Write new blog </h3>
    
    <hr>
    <br>

    <div class="col-md-12">
            
        <div id="errors"></div>
        <div id="success"></div>

        <form action="<?php echo e(route('post.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group col-12">
              <label for="title">Title:</label>
              <input type="" class="form-control" id="title" placeholder="Enter title" name="title">
            </div>

            <div class="form-group col-12">
              <label for="Body">Post Body:</label>
              <textarea class="form-control" id="body" name="body" rows="7">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque facilis fugit, laboriosam. Velit pariatur reiciendis nostrum dolore vero sunt repellendus minus quos nesciunt officia, ipsa necessitatibus, qui, consequuntur laudantium deleniti.
              </textarea> 
            </div>

            <button type="submit" class="btn btn-default col-12">Submit</button>

        </form>

    </div>
        
    <script>
        $(document).ready(function() { 

            $('button[type="submit"]').on('click', function(event) {
                event.preventDefault();
                
                if (confirm("Are Sure you want to insert data ")) {
                    var _token = $('[name="_token"]').val();
                    var title = $('[name="title"]').val();
                    var body = $('[name="body"]').val();

                    $.ajax({
                        url: '/post',
                        type: 'POST',
                        data: {
                            _token:_token, 
                            title:title, 
                            body:body 
                        },
                        success:function(response){
                            console.log(response);
                            alert(response);

                            // Set Null 
                            $('[name="title"]').val('');
                            $('[name="body"]').val('');

                            $('div#errors').empty();

                            $('div#success').append('<div class="alert alert-success">Data Inserted into Database </div>');
                        },
                        error:function(response){
                            var errors = response.responseJSON.errors;

                            $('div#success').empty();
                            $('div#errors').empty();
                            
                            $.each(errors, function(name, val) {
                                console.log(val);
                                var html_div ='<div class="alert alert-danger"><b>'+name+'</b>:'+val+'</div>';
                                $('div#errors').append(html_div);
                            });
                        }// Error:fucntion()

                    }); // Ajax 

                }// Comform Box
            }); // Btn CLick    
        });// document.ready.Jquery
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>