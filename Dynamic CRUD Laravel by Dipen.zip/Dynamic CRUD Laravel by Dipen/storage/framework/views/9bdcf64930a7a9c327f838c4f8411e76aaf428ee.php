<?php $__env->startSection('content'); ?>
  
<head><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" /></head>

  
  <?php echo $__env->make('model_crud.model_crud_script',[$crud_table], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <p> <?php echo e(@$test); ?> </p>

  
  <?php $__env->startComponent('layout.components.window_card',['title'=>$crud_table]); ?>
    <div id="db_records">
        <?php echo $__env->make("model_crud.{$crud_table}._table", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
    </div>
  <?php echo $__env->renderComponent(); ?>
          
          
  
  <?php $__env->startComponent('layout.components.modal',['modal_id'=> $crud_table.'_modal']); ?>
    <div id="ajax_modal">      
        <h3>Please Wait.....</h3>
    </div>
  <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>