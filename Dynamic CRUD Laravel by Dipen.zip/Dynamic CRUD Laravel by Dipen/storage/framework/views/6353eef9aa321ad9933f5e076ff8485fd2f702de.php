<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title> <?php echo e(@$title); ?> </title>

	
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css ')); ?>">

	
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js ')); ?>"> </script>

</head>
<body>

	<nav class="navbar navbar-expand-sm center bg-dark" style="background-color: #ddebd8 !important">
	  <ul class="navbar-nav">

	    <li class="nav-item">
	      <a class="nav-link" href="/post"> Blogs </a>
	    </li>

	    <li class="nav-item">
	      <a class="nav-link" href="/post/create"> New_Blog </a>
	    </li>

	    

	  </ul>
	</nav>
	<br>
    
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>