<?php $__env->startComponent('layout.components.model_curd_form',['crud_table'=>$crud_table]); ?> 
<div class="row">
    <div class="col">
        <div class="form-group">
                <h1><?php echo e(@$categories); ?> helo</h1>
                <h1><?php echo e(@$form_data); ?> helo</h1>
            <select class="custom-select form-control" id="category_id" name="category_id">
                <option value="1"> category_name </option>
                <option value="2"> Cate 2 </option>

                
                
                
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <input type="text" id="userinput4" class="form-control border-success" placeholder="Name" name="name">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <textarea class="form-control" name="desc" id="desc_id" cols="28" rows="5" placeholder="Description"></textarea>
        </div>
    </div>
</div>

<?php echo $__env->renderComponent(); ?>