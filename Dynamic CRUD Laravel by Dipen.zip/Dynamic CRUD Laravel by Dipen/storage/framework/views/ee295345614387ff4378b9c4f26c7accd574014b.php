<form action="<?php echo e(route($crud_table.'.store')); ?>">
    <?php echo csrf_field(); ?>
    <h4 class="form-section"><i class="la la-eye"></i>Add  <?php echo e($crud_table); ?></h4>    
    <div class="form-body">
    <?php echo e($slot); ?>

    </div>
    
    <div class="modal-footer">
        <button type="button" class="btn box-shadow-1 round btn-outline-blue-grey grey" data-dismiss="modal">Close</button>
        <button type="button" id="<?php echo e($crud_table); ?>_submit_btn" class="btn box-shadow-1 round btn-outline-success">Save</button>
    </div>
</form>