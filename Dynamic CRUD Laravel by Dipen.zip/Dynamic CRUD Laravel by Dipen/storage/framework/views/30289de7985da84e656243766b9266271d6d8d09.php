
<nav class="navbar navbar-expand-sm center bg-dark">
  <ul class="navbar-nav">

    <li class="nav-item">
      <a class="nav-link" href="/post"> Blogs </a>
    </li>

    

  </ul>
</nav>
<br>