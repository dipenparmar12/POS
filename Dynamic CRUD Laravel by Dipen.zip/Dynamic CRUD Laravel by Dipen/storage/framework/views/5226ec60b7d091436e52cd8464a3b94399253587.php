<?php $__env->startSection('content'); ?>

    <h1> Blogs by Atmiya college </h1>
    <p>  hello World how are you,,,,, Lorem ipsum dolor sit amet, consectetur.</p> <br>

    <?php if( count($posts) > 0 ): ?>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h1> <a href="posts/<?php echo e($post->id); ?>"> <?php echo e($post->title); ?> </a></h1>
            <small> <?php echo e($post->created_at); ?> </small>
            <p> <?php echo e($post->body); ?> </p>
            <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
        <p>There is no Posts </p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>