@component('layout.components.model_curd_form',['crud_table'=>$crud_table]) 
  <div class="row">
    {{-- Compnay_id determinded by login  --}}  
    <div class="col-md-4">
      <div class="form-group">
        <label for="id_category_name"> User Name </label>
        <input type="text" id="id_category_name" class="form-control border-success" placeholder="Category Name" value="test" name="name">
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="id_category_nick_name">Email</label>
        <input type="email" id="id_name" class="form-control border-success" placeholder="EMAIL ID " value="test" name="email">
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="id_category_nick_name">Password</label>
        <input type="text" id="id_name" class="form-control border-success" placeholder="password ID " value="test" name="password">
      </div>
    </div>
  </div>
@endcomponent