<alert class="alert alert-{{ $type }}">
	{{ $slot }}
</alert>