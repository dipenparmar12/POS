<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        for ($i=0; $i <10 ; $i++) { 
            DB::table('users')->insert([
                'name' => 'User '.$i,
                'email' => "dipen".rand(1,4000).'@gmail.com',
                'password' => "2018".$i.$i.$i,
            ]);

            for ($j=0; $j < 5; $j++) { 
                DB::table('subcategories')->insert([
                    'category_id' => $i,
                    'name' => "Cateogry name ".$i,
                    'desc' => "Cateogry id ".$i." Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iure, voluptatibus.".rand(1,4000),
                ]);
            }
        }
    }
}
