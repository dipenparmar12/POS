<?php
Session::put('company_id' , 1 );

//  CRUD Oprations 
Route::get('/', function () {
    return view('main');
});

Route::resource('/User', 'UserController');
Route::post('/User/table_records', 'UserController@table_records');

Route::resource('/Category', 'CategoryController');
Route::post('/Category/table_records', 'CategoryController@table_records');
    
Route::resource('/SubCategory', 'SubCategoryController');
Route::post('/SubCategory/table_records', 'SubCategoryController@table_records');
