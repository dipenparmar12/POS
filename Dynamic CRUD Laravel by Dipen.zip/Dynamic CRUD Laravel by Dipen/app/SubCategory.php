<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class SubCategory extends Model
{

	protected $table = 'subCategories';
	
    protected $fillable = [
    	'category_id',
		'name',
		'desc',
	];

    public function item(){
    	return $this->hasMany('App\Item');
    }

 	public function Category(){
 		return $this->belongsTo('App\Category');
 	}   

}
