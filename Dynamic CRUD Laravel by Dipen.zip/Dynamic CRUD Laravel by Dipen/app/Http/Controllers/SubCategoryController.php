<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubCategoryController extends ModelCrudController
{
    
    public function index( $data = null ){
        // $data['anyData_variable'] = $this->get_model('ANY_Model_name')->all();
    	$data['form_data']['categories'] = $this->get_model('category')->all();
    	return ModelCrudController::index($data);
    }

}
