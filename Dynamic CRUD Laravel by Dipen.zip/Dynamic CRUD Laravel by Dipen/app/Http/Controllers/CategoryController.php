<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryController extends ModelCrudController
{	
	// protected $model = 'User';

} // #end of Category Class
