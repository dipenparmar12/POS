<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    protected $fillable = [
    	'company_id',
		'name',
		'desc',
    ];

    

    public function subCategory(){
    	return $this->hasMany('App\SubCategory');
    }
    

	# // set all data fillabe in model ?
    // protected $fillable = ['*'];

}
